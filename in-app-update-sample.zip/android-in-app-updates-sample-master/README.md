# android-in-app-updates-sample
Android in-app updates API sample and integration test code with FakeAppUpdateManager.

#### Official document
https://developer.android.com/guide/app-bundle/in-app-updates
